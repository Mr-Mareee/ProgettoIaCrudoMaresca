# Generated from DLVParser.g4 by ANTLR 4.7
# encoding: utf-8
from __future__ import print_function
from antlr4 import *
from io import StringIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write(u"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3")
        buf.write(u"\30z\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write(u"\4\b\t\b\4\t\t\t\3\2\3\2\3\2\7\2\26\n\2\f\2\16\2\31\13")
        buf.write(u"\2\3\2\3\2\3\2\3\2\3\2\5\2 \n\2\3\2\3\2\3\2\3\2\7\2&")
        buf.write(u"\n\2\f\2\16\2)\13\2\3\2\5\2,\n\2\3\2\3\2\3\2\5\2\61\n")
        buf.write(u"\2\3\3\3\3\3\3\3\3\7\3\67\n\3\f\3\16\3:\13\3\3\3\3\3")
        buf.write(u"\3\4\3\4\3\4\3\4\3\4\3\4\3\5\3\5\3\5\3\5\7\5H\n\5\f\5")
        buf.write(u"\16\5K\13\5\5\5M\n\5\3\5\3\5\3\6\7\6R\n\6\f\6\16\6U\13")
        buf.write(u"\6\3\7\3\7\3\7\3\7\3\7\7\7\\\n\7\f\7\16\7_\13\7\3\7\3")
        buf.write(u"\7\5\7c\n\7\3\b\3\b\3\b\3\b\3\b\3\b\3\b\7\bl\n\b\f\b")
        buf.write(u"\16\bo\13\b\5\bq\n\b\3\b\3\b\5\bu\n\b\3\t\3\t\3\t\3\t")
        buf.write(u"\2\2\n\2\4\6\b\n\f\16\20\2\2\2\u0084\2\60\3\2\2\2\4\62")
        buf.write(u"\3\2\2\2\6=\3\2\2\2\bC\3\2\2\2\nS\3\2\2\2\fV\3\2\2\2")
        buf.write(u"\16t\3\2\2\2\20v\3\2\2\2\22\27\7\16\2\2\23\24\7\r\2\2")
        buf.write(u"\24\26\7\16\2\2\25\23\3\2\2\2\26\31\3\2\2\2\27\25\3\2")
        buf.write(u"\2\2\27\30\3\2\2\2\30\32\3\2\2\2\31\27\3\2\2\2\32\33")
        buf.write(u"\7\t\2\2\33\34\7\24\2\2\34\37\7\26\2\2\35 \7\25\2\2\36")
        buf.write(u" \5\20\t\2\37\35\3\2\2\2\37\36\3\2\2\2 \61\3\2\2\2!\61")
        buf.write(u"\5\b\5\2\"\'\5\16\b\2#$\7\r\2\2$&\5\16\b\2%#\3\2\2\2")
        buf.write(u"&)\3\2\2\2\'%\3\2\2\2\'(\3\2\2\2(\61\3\2\2\2)\'\3\2\2")
        buf.write(u"\2*,\7\f\2\2+*\3\2\2\2+,\3\2\2\2,-\3\2\2\2-.\5\b\5\2")
        buf.write(u"./\5\4\3\2/\61\3\2\2\2\60\22\3\2\2\2\60!\3\2\2\2\60\"")
        buf.write(u"\3\2\2\2\60+\3\2\2\2\61\3\3\2\2\2\62\63\7\5\2\2\638\5")
        buf.write(u"\6\4\2\64\65\7\r\2\2\65\67\5\6\4\2\66\64\3\2\2\2\67:")
        buf.write(u"\3\2\2\28\66\3\2\2\289\3\2\2\29;\3\2\2\2:8\3\2\2\2;<")
        buf.write(u"\7\6\2\2<\5\3\2\2\2=>\7\7\2\2>?\7\17\2\2?@\7\4\2\2@A")
        buf.write(u"\7\17\2\2AB\7\b\2\2B\7\3\2\2\2CL\7\n\2\2DI\5\f\7\2EF")
        buf.write(u"\7\r\2\2FH\5\f\7\2GE\3\2\2\2HK\3\2\2\2IG\3\2\2\2IJ\3")
        buf.write(u"\2\2\2JM\3\2\2\2KI\3\2\2\2LD\3\2\2\2LM\3\2\2\2MN\3\2")
        buf.write(u"\2\2NO\7\13\2\2O\t\3\2\2\2PR\5\2\2\2QP\3\2\2\2RU\3\2")
        buf.write(u"\2\2SQ\3\2\2\2ST\3\2\2\2T\13\3\2\2\2US\3\2\2\2Vb\7\16")
        buf.write(u"\2\2WX\7\21\2\2X]\5\16\b\2YZ\7\r\2\2Z\\\5\16\b\2[Y\3")
        buf.write(u"\2\2\2\\_\3\2\2\2][\3\2\2\2]^\3\2\2\2^`\3\2\2\2_]\3\2")
        buf.write(u"\2\2`a\7\22\2\2ac\3\2\2\2bW\3\2\2\2bc\3\2\2\2c\r\3\2")
        buf.write(u"\2\2du\7\16\2\2eu\7\17\2\2fu\5\f\7\2gp\7\7\2\2hm\5\16")
        buf.write(u"\b\2ij\7\r\2\2jl\5\16\b\2ki\3\2\2\2lo\3\2\2\2mk\3\2\2")
        buf.write(u"\2mn\3\2\2\2nq\3\2\2\2om\3\2\2\2ph\3\2\2\2pq\3\2\2\2")
        buf.write(u"qr\3\2\2\2ru\7\b\2\2su\7\20\2\2td\3\2\2\2te\3\2\2\2t")
        buf.write(u"f\3\2\2\2tg\3\2\2\2ts\3\2\2\2u\17\3\2\2\2vw\7\30\2\2")
        buf.write(u"wx\5\b\5\2x\21\3\2\2\2\20\27\37\'+\608ILS]bmpt")
        return buf.getvalue()


class DLVParser ( Parser ):

    grammarFileName = "DLVParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ u"<INVALID>", u"<INVALID>", u"':'", u"'Cost ([Weight:Level]): <'", 
                     u"'>'", u"'['", u"']'", u"' is '", u"'{'", u"'}'", 
                     u"'Best model:'", u"','", u"<INVALID>", u"<INVALID>", 
                     u"<INVALID>", u"'('", u"')'", u"<INVALID>", u"<INVALID>", 
                     u"'.'", u"<INVALID>", u"<INVALID>", u"', evidenced by'" ]

    symbolicNames = [ u"<INVALID>", u"HEADER", u"COLON", u"COST_BEGIN", 
                      u"COST_END", u"OPEN_SQUARE_BRACKET", u"CLOSE_SQUARE_BRACKET", 
                      u"GROUND_QUERY_BEGIN", u"MODEL_BEGIN", u"MODEL_END", 
                      u"WEIGHTED_MODEL_LABEL", u"COMMA", u"IDENTIFIER", 
                      u"INTEGER_CONSTANT", u"STRING_CONSTANT", u"TERMS_BEGIN", 
                      u"TERMS_END", u"WHITESPACE", u"REASONING", u"DOT", 
                      u"BOOLEAN", u"WHITESPACE_IN_GROUND_QUERY", u"WITNESS_LABEL" ]

    RULE_answer_set = 0
    RULE_cost = 1
    RULE_cost_level = 2
    RULE_model = 3
    RULE_output = 4
    RULE_predicate = 5
    RULE_term = 6
    RULE_witness = 7

    ruleNames =  [ u"answer_set", u"cost", u"cost_level", u"model", u"output", 
                   u"predicate", u"term", u"witness" ]

    EOF = Token.EOF
    HEADER=1
    COLON=2
    COST_BEGIN=3
    COST_END=4
    OPEN_SQUARE_BRACKET=5
    CLOSE_SQUARE_BRACKET=6
    GROUND_QUERY_BEGIN=7
    MODEL_BEGIN=8
    MODEL_END=9
    WEIGHTED_MODEL_LABEL=10
    COMMA=11
    IDENTIFIER=12
    INTEGER_CONSTANT=13
    STRING_CONSTANT=14
    TERMS_BEGIN=15
    TERMS_END=16
    WHITESPACE=17
    REASONING=18
    DOT=19
    BOOLEAN=20
    WHITESPACE_IN_GROUND_QUERY=21
    WITNESS_LABEL=22

    def __init__(self, input, output=sys.stdout):
        super(DLVParser, self).__init__(input, output=output)
        self.checkVersion("4.7")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class Answer_setContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(DLVParser.Answer_setContext, self).__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return DLVParser.RULE_answer_set

     
        def copyFrom(self, ctx):
            super(DLVParser.Answer_setContext, self).copyFrom(ctx)



    class SimpleModelContext(Answer_setContext):

        def __init__(self, parser, ctx): # actually a DLVParser.Answer_setContext)
            super(DLVParser.SimpleModelContext, self).__init__(parser)
            self.copyFrom(ctx)

        def model(self):
            return self.getTypedRuleContext(DLVParser.ModelContext,0)


        def accept(self, visitor):
            if hasattr(visitor, "visitSimpleModel"):
                return visitor.visitSimpleModel(self)
            else:
                return visitor.visitChildren(self)


    class GroundQueryContext(Answer_setContext):

        def __init__(self, parser, ctx): # actually a DLVParser.Answer_setContext)
            super(DLVParser.GroundQueryContext, self).__init__(parser)
            self.copyFrom(ctx)

        def IDENTIFIER(self, i=None):
            if i is None:
                return self.getTokens(DLVParser.IDENTIFIER)
            else:
                return self.getToken(DLVParser.IDENTIFIER, i)
        def GROUND_QUERY_BEGIN(self):
            return self.getToken(DLVParser.GROUND_QUERY_BEGIN, 0)
        def REASONING(self):
            return self.getToken(DLVParser.REASONING, 0)
        def BOOLEAN(self):
            return self.getToken(DLVParser.BOOLEAN, 0)
        def DOT(self):
            return self.getToken(DLVParser.DOT, 0)
        def witness(self):
            return self.getTypedRuleContext(DLVParser.WitnessContext,0)

        def COMMA(self, i=None):
            if i is None:
                return self.getTokens(DLVParser.COMMA)
            else:
                return self.getToken(DLVParser.COMMA, i)

        def accept(self, visitor):
            if hasattr(visitor, "visitGroundQuery"):
                return visitor.visitGroundQuery(self)
            else:
                return visitor.visitChildren(self)


    class WeightedModelContext(Answer_setContext):

        def __init__(self, parser, ctx): # actually a DLVParser.Answer_setContext)
            super(DLVParser.WeightedModelContext, self).__init__(parser)
            self.copyFrom(ctx)

        def model(self):
            return self.getTypedRuleContext(DLVParser.ModelContext,0)

        def cost(self):
            return self.getTypedRuleContext(DLVParser.CostContext,0)

        def WEIGHTED_MODEL_LABEL(self):
            return self.getToken(DLVParser.WEIGHTED_MODEL_LABEL, 0)

        def accept(self, visitor):
            if hasattr(visitor, "visitWeightedModel"):
                return visitor.visitWeightedModel(self)
            else:
                return visitor.visitChildren(self)


    class NonGroundQueryContext(Answer_setContext):

        def __init__(self, parser, ctx): # actually a DLVParser.Answer_setContext)
            super(DLVParser.NonGroundQueryContext, self).__init__(parser)
            self.copyFrom(ctx)

        def term(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(DLVParser.TermContext)
            else:
                return self.getTypedRuleContext(DLVParser.TermContext,i)

        def COMMA(self, i=None):
            if i is None:
                return self.getTokens(DLVParser.COMMA)
            else:
                return self.getToken(DLVParser.COMMA, i)

        def accept(self, visitor):
            if hasattr(visitor, "visitNonGroundQuery"):
                return visitor.visitNonGroundQuery(self)
            else:
                return visitor.visitChildren(self)



    def answer_set(self):

        localctx = DLVParser.Answer_setContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_answer_set)
        self._la = 0 # Token type
        try:
            self.state = 46
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
            if la_ == 1:
                localctx = DLVParser.GroundQueryContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 16
                self.match(DLVParser.IDENTIFIER)
                self.state = 21
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==DLVParser.COMMA:
                    self.state = 17
                    self.match(DLVParser.COMMA)
                    self.state = 18
                    self.match(DLVParser.IDENTIFIER)
                    self.state = 23
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 24
                self.match(DLVParser.GROUND_QUERY_BEGIN)
                self.state = 25
                self.match(DLVParser.REASONING)
                self.state = 26
                self.match(DLVParser.BOOLEAN)
                self.state = 29
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [DLVParser.DOT]:
                    self.state = 27
                    self.match(DLVParser.DOT)
                    pass
                elif token in [DLVParser.WITNESS_LABEL]:
                    self.state = 28
                    self.witness()
                    pass
                else:
                    raise NoViableAltException(self)

                pass

            elif la_ == 2:
                localctx = DLVParser.SimpleModelContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 31
                self.model()
                pass

            elif la_ == 3:
                localctx = DLVParser.NonGroundQueryContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 32
                self.term()
                self.state = 37
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==DLVParser.COMMA:
                    self.state = 33
                    self.match(DLVParser.COMMA)
                    self.state = 34
                    self.term()
                    self.state = 39
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass

            elif la_ == 4:
                localctx = DLVParser.WeightedModelContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 41
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==DLVParser.WEIGHTED_MODEL_LABEL:
                    self.state = 40
                    self.match(DLVParser.WEIGHTED_MODEL_LABEL)


                self.state = 43
                self.model()
                self.state = 44
                self.cost()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class CostContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(DLVParser.CostContext, self).__init__(parent, invokingState)
            self.parser = parser

        def COST_BEGIN(self):
            return self.getToken(DLVParser.COST_BEGIN, 0)

        def cost_level(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(DLVParser.Cost_levelContext)
            else:
                return self.getTypedRuleContext(DLVParser.Cost_levelContext,i)


        def COST_END(self):
            return self.getToken(DLVParser.COST_END, 0)

        def COMMA(self, i=None):
            if i is None:
                return self.getTokens(DLVParser.COMMA)
            else:
                return self.getToken(DLVParser.COMMA, i)

        def getRuleIndex(self):
            return DLVParser.RULE_cost

        def accept(self, visitor):
            if hasattr(visitor, "visitCost"):
                return visitor.visitCost(self)
            else:
                return visitor.visitChildren(self)




    def cost(self):

        localctx = DLVParser.CostContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_cost)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 48
            self.match(DLVParser.COST_BEGIN)
            self.state = 49
            self.cost_level()
            self.state = 54
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==DLVParser.COMMA:
                self.state = 50
                self.match(DLVParser.COMMA)
                self.state = 51
                self.cost_level()
                self.state = 56
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 57
            self.match(DLVParser.COST_END)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Cost_levelContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(DLVParser.Cost_levelContext, self).__init__(parent, invokingState)
            self.parser = parser

        def OPEN_SQUARE_BRACKET(self):
            return self.getToken(DLVParser.OPEN_SQUARE_BRACKET, 0)

        def INTEGER_CONSTANT(self, i=None):
            if i is None:
                return self.getTokens(DLVParser.INTEGER_CONSTANT)
            else:
                return self.getToken(DLVParser.INTEGER_CONSTANT, i)

        def COLON(self):
            return self.getToken(DLVParser.COLON, 0)

        def CLOSE_SQUARE_BRACKET(self):
            return self.getToken(DLVParser.CLOSE_SQUARE_BRACKET, 0)

        def getRuleIndex(self):
            return DLVParser.RULE_cost_level

        def accept(self, visitor):
            if hasattr(visitor, "visitCost_level"):
                return visitor.visitCost_level(self)
            else:
                return visitor.visitChildren(self)




    def cost_level(self):

        localctx = DLVParser.Cost_levelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_cost_level)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 59
            self.match(DLVParser.OPEN_SQUARE_BRACKET)
            self.state = 60
            self.match(DLVParser.INTEGER_CONSTANT)
            self.state = 61
            self.match(DLVParser.COLON)
            self.state = 62
            self.match(DLVParser.INTEGER_CONSTANT)
            self.state = 63
            self.match(DLVParser.CLOSE_SQUARE_BRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ModelContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(DLVParser.ModelContext, self).__init__(parent, invokingState)
            self.parser = parser

        def MODEL_BEGIN(self):
            return self.getToken(DLVParser.MODEL_BEGIN, 0)

        def MODEL_END(self):
            return self.getToken(DLVParser.MODEL_END, 0)

        def predicate(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(DLVParser.PredicateContext)
            else:
                return self.getTypedRuleContext(DLVParser.PredicateContext,i)


        def COMMA(self, i=None):
            if i is None:
                return self.getTokens(DLVParser.COMMA)
            else:
                return self.getToken(DLVParser.COMMA, i)

        def getRuleIndex(self):
            return DLVParser.RULE_model

        def accept(self, visitor):
            if hasattr(visitor, "visitModel"):
                return visitor.visitModel(self)
            else:
                return visitor.visitChildren(self)




    def model(self):

        localctx = DLVParser.ModelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_model)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 65
            self.match(DLVParser.MODEL_BEGIN)
            self.state = 74
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==DLVParser.IDENTIFIER:
                self.state = 66
                self.predicate()
                self.state = 71
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==DLVParser.COMMA:
                    self.state = 67
                    self.match(DLVParser.COMMA)
                    self.state = 68
                    self.predicate()
                    self.state = 73
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 76
            self.match(DLVParser.MODEL_END)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class OutputContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(DLVParser.OutputContext, self).__init__(parent, invokingState)
            self.parser = parser

        def answer_set(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(DLVParser.Answer_setContext)
            else:
                return self.getTypedRuleContext(DLVParser.Answer_setContext,i)


        def getRuleIndex(self):
            return DLVParser.RULE_output

        def accept(self, visitor):
            if hasattr(visitor, "visitOutput"):
                return visitor.visitOutput(self)
            else:
                return visitor.visitChildren(self)




    def output(self):

        localctx = DLVParser.OutputContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_output)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 81
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << DLVParser.OPEN_SQUARE_BRACKET) | (1 << DLVParser.MODEL_BEGIN) | (1 << DLVParser.WEIGHTED_MODEL_LABEL) | (1 << DLVParser.IDENTIFIER) | (1 << DLVParser.INTEGER_CONSTANT) | (1 << DLVParser.STRING_CONSTANT))) != 0):
                self.state = 78
                self.answer_set()
                self.state = 83
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class PredicateContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(DLVParser.PredicateContext, self).__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(DLVParser.IDENTIFIER, 0)

        def TERMS_BEGIN(self):
            return self.getToken(DLVParser.TERMS_BEGIN, 0)

        def term(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(DLVParser.TermContext)
            else:
                return self.getTypedRuleContext(DLVParser.TermContext,i)


        def TERMS_END(self):
            return self.getToken(DLVParser.TERMS_END, 0)

        def COMMA(self, i=None):
            if i is None:
                return self.getTokens(DLVParser.COMMA)
            else:
                return self.getToken(DLVParser.COMMA, i)

        def getRuleIndex(self):
            return DLVParser.RULE_predicate

        def accept(self, visitor):
            if hasattr(visitor, "visitPredicate"):
                return visitor.visitPredicate(self)
            else:
                return visitor.visitChildren(self)




    def predicate(self):

        localctx = DLVParser.PredicateContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_predicate)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 84
            self.match(DLVParser.IDENTIFIER)
            self.state = 96
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==DLVParser.TERMS_BEGIN:
                self.state = 85
                self.match(DLVParser.TERMS_BEGIN)
                self.state = 86
                self.term()
                self.state = 91
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==DLVParser.COMMA:
                    self.state = 87
                    self.match(DLVParser.COMMA)
                    self.state = 88
                    self.term()
                    self.state = 93
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 94
                self.match(DLVParser.TERMS_END)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class TermContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(DLVParser.TermContext, self).__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(DLVParser.IDENTIFIER, 0)

        def INTEGER_CONSTANT(self):
            return self.getToken(DLVParser.INTEGER_CONSTANT, 0)

        def predicate(self):
            return self.getTypedRuleContext(DLVParser.PredicateContext,0)


        def OPEN_SQUARE_BRACKET(self):
            return self.getToken(DLVParser.OPEN_SQUARE_BRACKET, 0)

        def CLOSE_SQUARE_BRACKET(self):
            return self.getToken(DLVParser.CLOSE_SQUARE_BRACKET, 0)

        def term(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(DLVParser.TermContext)
            else:
                return self.getTypedRuleContext(DLVParser.TermContext,i)


        def COMMA(self, i=None):
            if i is None:
                return self.getTokens(DLVParser.COMMA)
            else:
                return self.getToken(DLVParser.COMMA, i)

        def STRING_CONSTANT(self):
            return self.getToken(DLVParser.STRING_CONSTANT, 0)

        def getRuleIndex(self):
            return DLVParser.RULE_term

        def accept(self, visitor):
            if hasattr(visitor, "visitTerm"):
                return visitor.visitTerm(self)
            else:
                return visitor.visitChildren(self)




    def term(self):

        localctx = DLVParser.TermContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_term)
        self._la = 0 # Token type
        try:
            self.state = 114
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 98
                self.match(DLVParser.IDENTIFIER)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 99
                self.match(DLVParser.INTEGER_CONSTANT)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 100
                self.predicate()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 101
                self.match(DLVParser.OPEN_SQUARE_BRACKET)
                self.state = 110
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << DLVParser.OPEN_SQUARE_BRACKET) | (1 << DLVParser.IDENTIFIER) | (1 << DLVParser.INTEGER_CONSTANT) | (1 << DLVParser.STRING_CONSTANT))) != 0):
                    self.state = 102
                    self.term()
                    self.state = 107
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==DLVParser.COMMA:
                        self.state = 103
                        self.match(DLVParser.COMMA)
                        self.state = 104
                        self.term()
                        self.state = 109
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                self.state = 112
                self.match(DLVParser.CLOSE_SQUARE_BRACKET)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 113
                self.match(DLVParser.STRING_CONSTANT)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class WitnessContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(DLVParser.WitnessContext, self).__init__(parent, invokingState)
            self.parser = parser

        def WITNESS_LABEL(self):
            return self.getToken(DLVParser.WITNESS_LABEL, 0)

        def model(self):
            return self.getTypedRuleContext(DLVParser.ModelContext,0)


        def getRuleIndex(self):
            return DLVParser.RULE_witness

        def accept(self, visitor):
            if hasattr(visitor, "visitWitness"):
                return visitor.visitWitness(self)
            else:
                return visitor.visitChildren(self)




    def witness(self):

        localctx = DLVParser.WitnessContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_witness)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 116
            self.match(DLVParser.WITNESS_LABEL)
            self.state = 117
            self.model()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





