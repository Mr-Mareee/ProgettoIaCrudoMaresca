from platforms.desktop.desktop_handler import DesktopHandler
from specializations.dlv2.desktop.dlv2_desktop_service import DLV2DesktopService
from languages.asp.asp_input_program import ASPInputProgram
from base.option_descriptor import OptionDescriptor

class DLVhandler:

    def __init__(self):
        self.fatti = ""
        self.regole = ""
        #con l'handler gestisco l'esecuzione del programma dlv2 con all'interno
        #l'eseguibile DLV2 (Se non funziona utilizzare chmod u+x)
        self.handler = DesktopHandler(DLV2DesktopService("DLV2/./dlv2-linux-64_6"))
        self.programVariable = ASPInputProgram()
        self.programFixed = ASPInputProgram()
        self.programFixed.add_files_path("DLV2/regole.txt")
        self.handler.add_program(self.programFixed)
        self.handler.add_program(self.programVariable)
    
    def getSoluzione(self):
        answersets = self.handler.start_sync()
        for a in answersets.get_answer_sets():
            return str(a)
    def trasferisciInDLV(self):
        self.programVariable.clear_all()
        self.programVariable.add_program(self.fatti)

    def setFatti(self,nodi,archi):
        self.fatti="dif(3)."
        for i in range(0,len(nodi)):
            self.fatti+=str(nodi[i])
        for i in range(0,len(archi)):
            self.fatti+=archi[i]
        #print("Fatti: " + self.fatti)
        